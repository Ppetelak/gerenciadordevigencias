const mysql = require("mysql2");
/* Conexão com banco de dados */

const db = mysql.createConnection({
    host: 'localhost',
    user: 'midiaIdeal_vigencias2',
    password: 'H^u003zy2',
    database: 'vigencias_db',
	  port: '3306'
});
  
db.connect((error) => {
    if (error) {
      console.error('Erro ao conectar ao banco de dados:', error);
    } else {
      console.log('Conexão bem-sucedida ao banco de dados');
    }
});

module.exports = { 
    db
};
